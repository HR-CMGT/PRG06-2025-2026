#!/bin/bash

# Check if the directory ~/www exists and is not empty
if [ ! -d ~/www ] || [ -z "$(ls -A ~/www)" ]; then
    echo "No project found in ~/www/. There is nothing to reset."
    exit 0
fi

# There can only be 1 project. The directory name in ~/www is our project_machine_name
project_machine_name=$(ls ~/www/ | head -n 1)

if [ -z "$project_machine_name" ]; then
    echo "Could not determine the project name. Reset aborted."
    exit 1
fi

echo "Reading project name '$project_machine_name' from ~/www/. Starting reset..."

# 1. Empty ~/www/ completely
echo "Emptying ~/www/ ..."
rm -rf ~/www/*

# 2. Empty /var/www/production completely
echo "Emptying /var/www/production ..."
if [ -d /var/www/production ]; then
    sudo rm -rf /var/www/production/*
fi

# 3. Remove specific Nginx configuration and symlink for this project
echo "Removing Nginx configuration for '$project_machine_name'..."
if [ -L /etc/nginx/sites-enabled/"$project_machine_name" ]; then
    sudo unlink /etc/nginx/sites-enabled/"$project_machine_name"
fi

if [ -f /etc/nginx/sites-available/"$project_machine_name" ]; then
    sudo rm /etc/nginx/sites-available/"$project_machine_name"
fi

# 4. Restore the default Nginx configuration (since the configure logic unlinks it)
if [ ! -L /etc/nginx/sites-enabled/default ] && [ -f /etc/nginx/sites-available/default ]; then
    echo "Restoring default Nginx configuration..."
    sudo ln -s /etc/nginx/sites-available/default /etc/nginx/sites-enabled/
fi

# Restart Nginx
echo "Restarting Nginx..."
sudo service nginx restart

echo "Reset completed! Your configuration is clean and ready for a new project."
